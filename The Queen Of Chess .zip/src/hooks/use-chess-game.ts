"use client";

import { useState, useCallback, useMemo } from 'react';
import type { Board, Move, Piece, PieceColor, GameStatus, Square } from '@/types';
import { createInitialBoard, getValidMoves } from '@/lib/chess-logic';
import { useToast } from '@/hooks/use-toast';

export function useChessGame() {
  const [board, setBoard] = useState<Board>(createInitialBoard);
  const [turn, setTurn] = useState<PieceColor>('w');
  const [gameStatus, setGameStatus] = useState<GameStatus>('in-progress');
  const [moveHistory, setMoveHistory] = useState<Move[]>([]);
  const [capturedPieces, setCapturedPieces] = useState<{ w: Piece[], b: Piece[] }>({ w: [], b: [] });
  const { toast } = useToast();

  const resetGame = useCallback(() => {
    setBoard(createInitialBoard());
    setTurn('w');
    setGameStatus('in-progress');
    setMoveHistory([]);
    setCapturedPieces({ w: [], b: [] });
  }, []);

  const movePiece = useCallback((move: Move): boolean => {
    const { from, to } = move;
    const piece = board[from.row][from.col];

    if (!piece || piece.color !== turn || gameStatus !== 'in-progress') {
      return false;
    }

    const validMoves = getValidMoves(from.row, from.col, board);
    const isValidMove = validMoves.some(m => m.to.row === to.row && m.to.col === to.col);

    if (!isValidMove) {
      toast({
        title: "Invalid Move",
        description: "You can't move that piece there.",
        variant: "destructive",
      });
      return false;
    }

    const newBoard = structuredClone(board);
    const captured = newBoard[to.row][to.col];
    
    // Simple pawn promotion to queen
    if (piece.type === 'pawn' && (to.row === 0 || to.row === 7)) {
        newBoard[to.row][to.col] = { type: 'queen', color: piece.color };
    } else {
        newBoard[to.row][to.col] = piece;
    }
    
    newBoard[from.row][from.col] = null;

    if (captured) {
      const newCaptured = { ...capturedPieces };
      if (captured.color === 'w') {
        newCaptured.b.push(captured);
      } else {
        newCaptured.w.push(captured);
      }
      setCapturedPieces(newCaptured);
    }
    
    setBoard(newBoard);
    setMoveHistory(prev => [...prev, move]);
    
    // Check for checkmate
    const opponentColor = turn === 'w' ? 'b' : 'w';
    const isInCheck = isKingInCheck(opponentColor, newBoard);
    const hasValidMoves = getAllPossibleMoves(newBoard, opponentColor).length > 0;

    if (isInCheck && !hasValidMoves) {
        setGameStatus('checkmate');
    } else if (!isInCheck && !hasValidMoves) {
        setGameStatus('stalemate');
    } else {
       setTurn(prev => (prev === 'w' ? 'b' : 'w'));
    }

    return true;
  }, [board, turn, gameStatus, capturedPieces, toast]);
  
  const isKingInCheck = (kingColor: PieceColor, currentBoard: Board): boolean => {
      const kingPosition = findKing(kingColor, currentBoard);
      if (!kingPosition) return false; // Should not happen
      
      const opponentColor = kingColor === 'w' ? 'b' : 'w';
      const opponentMoves = getAllPossibleMoves(currentBoard, opponentColor);
      
      return opponentMoves.some(move => move.to.row === kingPosition.row && move.to.col === kingPosition.col);
  }
  
  const findKing = (color: PieceColor, currentBoard: Board): { row: number, col: number } | null => {
      for (let r = 0; r < 8; r++) {
          for (let c = 0; c < 8; c++) {
              const piece = currentBoard[r][c];
              if (piece && piece.type === 'king' && piece.color === color) {
                  return { row: r, col: c };
              }
          }
      }
      return null;
  }
  
  const getAllPossibleMoves = (board: Board, color: PieceColor): Move[] => {
    const allMoves: Move[] = [];
    for (let r = 0; r < 8; r++) {
      for (let c = 0; c < 8; c++) {
        const piece = board[r][c];
        if (piece && piece.color === color) {
          allMoves.push(...getValidMoves(r, c, board));
        }
      }
    }
    return allMoves;
  }

  const resign = useCallback((color: PieceColor) => {
    setGameStatus('resigned');
    const winner = color === 'w' ? 'Black' : 'White';
    toast({
      title: 'Game Over',
      description: `${color === 'w' ? 'White' : 'Black'} resigned. ${winner} wins!`,
    });
  }, [toast]);
  
  const offerDraw = useCallback(() => {
    // In a real app, this would need opponent confirmation
    setGameStatus('draw');
     toast({
      title: 'Draw',
      description: `The game is a draw by agreement.`,
    });
  }, [toast]);


  const gameContextValue = useMemo(() => ({
    board,
    turn,
    gameStatus,
    moveHistory,
    capturedPieces,
    movePiece,
    resetGame,
    resign,
    offerDraw,
    getValidMoves: (row: number, col: number) => getValidMoves(row, col, board),
  }), [board, turn, gameStatus, moveHistory, capturedPieces, movePiece, resetGame, resign, offerDraw]);

  return gameContextValue;
}
