'use server';
/**
 * @fileOverview This file defines a Genkit flow for selecting the AI difficulty level in the ChessMate game.
 *
 * It includes the `selectAIDifficulty` function, the `AIDifficultyInput` type, and the `AIDifficultyOutput` type.
 */

import {ai} from '@/ai/genkit';
import {z} from 'genkit';

const AIDifficultyInputSchema = z.object({
  difficulty: z
    .enum(['easy', 'normal', 'hard'])
    .describe('The desired difficulty level for the AI opponent.'),
});
export type AIDifficultyInput = z.infer<typeof AIDifficultyInputSchema>;

const AIDifficultyOutputSchema = z.object({
  difficulty: z
    .enum(['easy', 'normal', 'hard'])
    .describe('The selected difficulty level for the AI opponent.'),
  description: z
    .string()
    .describe('A short description of the selected difficulty level.'),
});
export type AIDifficultyOutput = z.infer<typeof AIDifficultyOutputSchema>;

export async function selectAIDifficulty(input: AIDifficultyInput): Promise<AIDifficultyOutput> {
  return selectAIDifficultyFlow(input);
}

const prompt = ai.definePrompt({
  name: 'aiDifficultyPrompt',
  input: {schema: AIDifficultyInputSchema},
  output: {schema: AIDifficultyOutputSchema},
  prompt: `You are an expert chess AI difficulty selector.

You will use the difficulty level provided to return the difficulty and a short description.

Difficulty: {{{difficulty}}}
`,
});

const selectAIDifficultyFlow = ai.defineFlow(
  {
    name: 'selectAIDifficultyFlow',
    inputSchema: AIDifficultyInputSchema,
    outputSchema: AIDifficultyOutputSchema,
  },
  async input => {
    const {output} = await prompt(input);
    return output!;
  }
);
