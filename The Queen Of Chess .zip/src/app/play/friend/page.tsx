"use client";

import { useMemo } from 'react';
import { useChessGame } from '@/hooks/use-chess-game';
import { Chessboard } from '@/components/chessboard';
import { GameControls } from '@/components/game-controls';
import { GameOverDialog } from '@/components/game-over-dialog';

export default function PlayFriendPage() {
  const game = useChessGame();
  
  const isGameOver = useMemo(() => game.gameStatus !== 'in-progress', [game.gameStatus]);
  const winner = useMemo(() => {
    if (game.gameStatus === 'checkmate' || game.gameStatus === 'resigned') {
      return game.turn === 'w' ? 'b' : 'w';
    }
    return undefined;
  }, [game.gameStatus, game.turn]);
  
  return (
    <>
      <div className="flex flex-col md:flex-row items-center justify-center h-screen p-4 gap-4">
        <div className="w-full md:w-auto flex-1 flex items-center justify-center max-w-full md:max-w-[calc(100vh-8rem)]">
          <Chessboard board={game.board} onMove={game.movePiece} getValidMoves={game.getValidMoves} turn={game.turn} />
        </div>
        <div className="w-full md:w-64 flex flex-col justify-center gap-4">
            <GameControls onReset={game.resetGame} onDraw={game.offerDraw} />
        </div>
      </div>
      <GameOverDialog status={game.gameStatus} winner={winner} isOpen={isGameOver} onNewGame={game.resetGame} />
    </>
  );
}
