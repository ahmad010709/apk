"use client";

import { useState, useMemo, useEffect } from 'react';
import { useChessGame } from '@/hooks/use-chess-game';
import { Chessboard } from '@/components/chessboard';
import { GameControls } from '@/components/game-controls';
import { GameOverDialog } from '@/components/game-over-dialog';
import type { PieceColor, Move, Board } from '@/types';
import { selectAIDifficulty } from '@/ai/flows/ai-difficulty-selection';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { RadioGroup, RadioGroupItem } from '@/components/ui/radio-group';
import { Label } from '@/components/ui/label';
import { Loader2, Bot } from 'lucide-react';

type Difficulty = 'easy' | 'normal' | 'hard';
type GameStage = 'difficulty_select' | 'in_game';

function getAIMove(board: Board, difficulty: Difficulty, color: PieceColor): Move | null {
  const possibleMoves = getAllPossibleMoves(board, color);
  if (possibleMoves.length === 0) return null;

  if (difficulty === 'easy') {
    return possibleMoves[Math.floor(Math.random() * possibleMoves.length)];
  }

  let bestMove: Move | null = null;
  let bestValue = -Infinity;

  // Prioritize captures
  const captureMoves = possibleMoves.filter(move => board[move.to.row][move.to.col] !== null);
  if (difficulty === 'normal' && captureMoves.length > 0) {
    return captureMoves[Math.floor(Math.random() * captureMoves.length)];
  }

  // Simple evaluation for 'hard'
  if (difficulty === 'hard') {
    const pieceValues: { [key: string]: number } = { pawn: 1, knight: 3, bishop: 3, rook: 5, queen: 9, king: 100 };
    for (const move of possibleMoves) {
        let moveValue = 0;
        const capturedPiece = board[move.to.row][move.to.col];
        if (capturedPiece) {
            moveValue = pieceValues[capturedPiece.type] || 0;
        }
        if (moveValue > bestValue) {
            bestValue = moveValue;
            bestMove = move;
        }
    }
    return bestMove || possibleMoves[Math.floor(Math.random() * possibleMoves.length)];
  }

  return possibleMoves[Math.floor(Math.random() * possibleMoves.length)];
}

// Helper from lib/chess-logic to avoid circular dependencies in hooks
function getAllPossibleMoves(board: Board, color: PieceColor): Move[] {
    const allMoves: Move[] = [];
    for (let r = 0; r < 8; r++) {
      for (let c = 0; c < 8; c++) {
        const piece = board[r][c];
        if (piece && piece.color === color) {
          allMoves.push(...getValidMoves(r, c, board));
        }
      }
    }
    return allMoves;
}

// Helper from lib/chess-logic
function getValidMoves(row: number, col: number, board: Board): Move[] {
  const piece = board[row]?.[col];
  if (!piece) return [];

  const moves: Move[] = [];
  const from = { row, col };
  const { type, color } = piece;

  const addMove = (toRow: number, toCol: number) => {
    if (toRow >= 0 && toRow < 8 && toCol >= 0 && toCol < 8) {
      const targetPiece = board[toRow][toCol];
      if (targetPiece === null || targetPiece.color !== color) {
        moves.push({ from, to: { row: toRow, col: toCol } });
      }
    }
  };

  const addSlidingMoves = (directions: number[][]) => {
    for (const [dr, dc] of directions) {
      let r = row + dr;
      let c = col + dc;
      while (r >= 0 && r < 8 && c >= 0 && c < 8) {
        const targetPiece = board[r][c];
        if (targetPiece === null) {
          moves.push({ from, to: { row: r, col: c } });
        } else {
          if (targetPiece.color !== color) {
            moves.push({ from, to: { row: r, col: c } });
          }
          break;
        }
        r += dr;
        c += dc;
      }
    }
  };

  switch (type) {
    case 'pawn':
      const dir = color === 'w' ? -1 : 1;
      const startRow = color === 'w' ? 6 : 1;
      if (board[row + dir]?.[col] === null) {
        addMove(row + dir, col);
        if (row === startRow && board[row + 2 * dir]?.[col] === null) {
          addMove(row + 2 * dir, col);
        }
      }
      [-1, 1].forEach(side => {
        if (board[row + dir]?.[col + side] && board[row + dir][col + side]?.color !== color) {
          addMove(row + dir, col + side);
        }
      });
      break;
    case 'knight':
      [[ -2, -1 ], [ -2, 1 ], [ -1, -2 ], [ -1, 2 ], [ 1, -2 ], [ 1, 2 ], [ 2, -1 ], [ 2, 1 ]].forEach(([dr, dc]) => addMove(row + dr, col + dc));
      break;
    case 'bishop':
      addSlidingMoves([[-1, -1], [-1, 1], [1, -1], [1, 1]]);
      break;
    case 'rook':
      addSlidingMoves([[-1, 0], [1, 0], [0, -1], [0, 1]]);
      break;
    case 'queen':
      addSlidingMoves([[-1, -1], [-1, 1], [1, -1], [1, 1], [-1, 0], [1, 0], [0, -1], [0, 1]]);
      break;
    case 'king':
      [[-1, -1], [-1, 0], [-1, 1], [0, -1], [0, 1], [1, -1], [1, 0], [1, 1]].forEach(([dr, dc]) => addMove(row + dr, col + dc));
      break;
  }
  return moves;
}

export default function PlayAIPage() {
  const [stage, setStage] = useState<GameStage>('difficulty_select');
  const [difficulty, setDifficulty] = useState<Difficulty>('normal');
  const [aiDescription, setAiDescription] = useState('A balanced opponent that provides a good challenge.');
  const [loadingDescription, setLoadingDescription] = useState(false);

  const game = useChessGame();
  
  const isGameOver = useMemo(() => game.gameStatus !== 'in-progress', [game.gameStatus]);
  const winner = useMemo(() => {
    if (game.gameStatus === 'checkmate' || game.gameStatus === 'resigned') {
      return game.turn === 'w' ? 'b' : 'w';
    }
    return undefined;
  }, [game.gameStatus, game.turn]);

  useEffect(() => {
    if (game.turn === 'b' && !isGameOver) {
      const timer = setTimeout(() => {
        const aiMove = getAIMove(game.board, difficulty, 'b');
        if (aiMove) {
          game.movePiece(aiMove);
        }
      }, 700);
      return () => clearTimeout(timer);
    }
  }, [game.turn, game.board, isGameOver, difficulty, game]);

  const handleDifficultyChange = async (value: Difficulty) => {
    setDifficulty(value);
    setLoadingDescription(true);
    try {
        const result = await selectAIDifficulty({ difficulty: value });
        setAiDescription(result.description);
    } catch (error) {
        console.error("Failed to get AI description:", error);
        setAiDescription("Could not load AI description for this level.");
    } finally {
        setLoadingDescription(false);
    }
  };
  
  const handleStartGame = () => {
    game.resetGame();
    setStage('in_game');
  }

  if (stage === 'difficulty_select') {
    return (
      <div className="flex flex-col items-center justify-center p-4 min-h-screen bg-background">
        <Card className="w-full max-w-md shadow-2xl">
          <CardHeader>
            <CardTitle className="text-center text-3xl font-bold flex items-center justify-center gap-2"><Bot /> Select Difficulty</CardTitle>
            <CardDescription className="text-center">Choose your opponent's skill level.</CardDescription>
          </CardHeader>
          <CardContent className="space-y-6">
            <RadioGroup defaultValue={difficulty} onValueChange={handleDifficultyChange} className="grid grid-cols-3 gap-4">
              <div>
                <RadioGroupItem value="easy" id="easy" className="peer sr-only" />
                <Label htmlFor="easy" className="flex flex-col items-center justify-between rounded-md border-2 border-muted bg-popover p-4 hover:bg-accent hover:text-accent-foreground peer-data-[state=checked]:border-primary [&:has([data-state=checked])]:border-primary">
                  Easy
                </Label>
              </div>
              <div>
                <RadioGroupItem value="normal" id="normal" className="peer sr-only" />
                <Label htmlFor="normal" className="flex flex-col items-center justify-between rounded-md border-2 border-muted bg-popover p-4 hover:bg-accent hover:text-accent-foreground peer-data-[state=checked]:border-primary [&:has([data-state=checked])]:border-primary">
                  Normal
                </Label>
              </div>
              <div>
                <RadioGroupItem value="hard" id="hard" className="peer sr-only" />
                <Label htmlFor="hard" className="flex flex-col items-center justify-between rounded-md border-2 border-muted bg-popover p-4 hover:bg-accent hover:text-accent-foreground peer-data-[state=checked]:border-primary [&:has([data-state=checked])]:border-primary">
                  Hard
                </Label>
              </div>
            </RadioGroup>
            <Card className="bg-muted/50 p-4 min-h-[6rem]">
              <CardDescription className="text-center">
                {loadingDescription ? <Loader2 className="mx-auto h-5 w-5 animate-spin" /> : aiDescription}
              </CardDescription>
            </Card>
            <Button size="lg" className="w-full" onClick={handleStartGame}>
              Start Game
            </Button>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <>
      <div className="flex flex-col md:flex-row items-center justify-center h-screen p-4 gap-4 bg-background">
        <div className="w-full md:w-auto flex-1 flex items-center justify-center max-w-full md:max-w-[calc(100vh-8rem)]">
          <Chessboard board={game.board} onMove={game.movePiece} getValidMoves={game.getValidMoves} turn={game.turn} />
        </div>
        <div className="w-full md:w-64 flex flex-col justify-center gap-4">
            <GameControls onReset={game.resetGame} onDraw={game.offerDraw} />
        </div>
      </div>
      <GameOverDialog status={game.gameStatus} winner={winner} isOpen={isGameOver} onNewGame={handleStartGame} onMenu={() => setStage('difficulty_select')} />
    </>
  );
}
