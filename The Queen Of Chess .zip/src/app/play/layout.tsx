import { Button } from "@/components/ui/button";
import { SettingsDialog } from "@/components/settings-dialog";
import { ArrowLeft, Crown } from "lucide-react";
import Link from "next/link";

export default function PlayLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <div className="min-h-screen bg-background text-foreground flex flex-col">
      <header className="flex items-center justify-between p-4 border-b border-border sticky top-0 bg-background/80 backdrop-blur-sm z-20">
        <div className="flex items-center gap-4">
          <Link href="/">
            <Button variant="outline" size="sm">
              <ArrowLeft className="mr-2 h-4 w-4" />
              Menu
            </Button>
          </Link>
          <Link href="/" className="flex items-center gap-2">
            <Crown className="h-6 w-6 text-primary" />
            <h1 className="text-xl font-bold text-primary-foreground font-headline hidden sm:block">
              The Queen Of Chess
            </h1>
          </Link>
        </div>
        <SettingsDialog />
      </header>
      <main className="flex-1 flex flex-col">
        {children}
      </main>
    </div>
  );
}
