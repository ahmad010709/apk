"use client";

import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { SettingsDialog } from "@/components/settings-dialog";
import { Users, Bot, Crown } from "lucide-react";
import Link from "next/link";

export default function Home() {
  return (
    <div className="relative min-h-screen w-full overflow-hidden">
      <div className="absolute inset-0 bg-grid-pattern bg-center [mask-image:linear-gradient(to_bottom,white_70%,transparent_100%)]"></div>
      <main className="relative z-10 flex min-h-screen flex-col items-center justify-center p-4">
        <div className="absolute top-4 right-4 md:top-6 md:right-6">
          <SettingsDialog />
        </div>
        <div className="text-center mb-12">
          <h1 className="flex items-center justify-center text-5xl md:text-7xl font-black tracking-tighter text-primary font-headline">
            <Crown className="h-12 w-12 md:h-16 md:w-16 mr-2 -rotate-12 text-accent" />
            The Queen Of Chess
          </h1>
          <p className="text-muted-foreground mt-2 text-lg">A royal chess experience.</p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 md:gap-8 max-w-3xl w-full">
          <Link href="/play/ai" className="group">
            <Card className="h-full flex flex-col items-center justify-center text-center p-6 md:p-8 border-2 border-transparent hover:border-primary hover:bg-card/60 transition-all duration-300 transform hover:-translate-y-1 shadow-lg hover:shadow-primary/20">
              <CardHeader className="p-0">
                <Bot className="h-16 w-16 md:h-20 md:w-20 mx-auto text-accent group-hover:scale-110 transition-transform duration-300" />
                <CardTitle className="mt-4 text-2xl md:text-3xl font-bold font-headline">Play vs AI</CardTitle>
                <CardDescription className="mt-2">Challenge our AI at various difficulty levels.</CardDescription>
              </CardHeader>
            </Card>
          </Link>

          <Link href="/play/friend" className="group">
            <Card className="h-full flex flex-col items-center justify-center text-center p-6 md:p-8 border-2 border-transparent hover:border-primary hover:bg-card/60 transition-all duration-300 transform hover:-translate-y-1 shadow-lg hover:shadow-primary/20">
              <CardHeader className="p-0">
                <Users className="h-16 w-16 md:h-20 md:w-20 mx-auto text-accent group-hover:scale-110 transition-transform duration-300" />
                <CardTitle className="mt-4 text-2xl md:text-3xl font-bold font-headline">Play vs Friend</CardTitle>
                <CardDescription className="mt-2">Play with a friend on the same device.</CardDescription>
              </CardHeader>
            </Card>
          </Link>
        </div>
        <footer className="absolute bottom-4 text-center text-muted-foreground text-sm">
          <p>Press <kbd className="pointer-events-none inline-flex h-5 select-none items-center gap-1 rounded border bg-muted px-1.5 font-mono text-[10px] font-medium text-muted-foreground opacity-100">
            <span className="text-xs">⌘</span>B
          </kbd> to toggle the sidebar in-game.</p>
        </footer>
      </main>
      <style jsx>{`
        .bg-grid-pattern {
          background-image: linear-gradient(to right, hsl(var(--border)) 1px, transparent 1px), linear-gradient(to bottom, hsl(var(--border)) 1px, transparent 1px);
          background-size: 3rem 3rem;
        }
      `}</style>
    </div>
  );
}
