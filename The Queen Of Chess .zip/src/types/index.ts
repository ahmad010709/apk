export type PieceType = 'pawn' | 'rook' | 'knight' | 'bishop' | 'queen' | 'king';
export type PieceColor = 'w' | 'b';

export interface Piece {
  type: PieceType;
  color: PieceColor;
}

export type Square = Piece | null;
export type Board = Square[][];

export interface Move {
  from: { row: number; col: number };
  to: { row: number; col: number };
}

export type GameStatus = 'in-progress' | 'checkmate' | 'stalemate' | 'draw' | 'resigned';
