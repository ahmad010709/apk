"use client";

import type { Piece } from '@/types';
import { Avatar, AvatarFallback } from '@/components/ui/avatar';
import { ChessPiece } from './chess-pieces';
import { cn } from '@/lib/utils';
import { User, Bot } from 'lucide-react';
import { ScrollArea, ScrollBar } from '@/components/ui/scroll-area';

interface PlayerInfoProps {
  name: string;
  isAI?: boolean;
  isTurn: boolean;
  capturedPieces: Piece[];
  className?: string;
}

export function PlayerInfo({ name, isAI = false, isTurn, capturedPieces, className }: PlayerInfoProps) {
  return (
    <div className={cn("p-2 sm:p-4 rounded-lg bg-card shadow-md transition-all duration-300", isTurn ? 'border-2 border-primary' : 'border-2 border-transparent', className)}>
      <div className="flex items-center gap-2 sm:gap-4">
        <Avatar className="h-10 w-10 sm:h-12 sm:w-12">
          <AvatarFallback className="bg-secondary">
            {isAI ? <Bot className="h-5 w-5 sm:h-6 sm:w-6" /> : <User className="h-5 w-5 sm:h-6 sm:w-6" />}
          </AvatarFallback>
        </Avatar>
        <div className="flex-1">
          <h3 className="text-base sm:text-lg font-bold truncate">{name}</h3>
          <p className={cn("text-xs sm:text-sm font-semibold transition-colors", isTurn ? 'text-primary' : 'text-muted-foreground')}>
            {isTurn ? 'Thinking...' : 'Waiting'}
          </p>
        </div>
      </div>
      <ScrollArea className="mt-2 h-10 w-full whitespace-nowrap">
        <div className="flex w-max space-x-1 p-1 bg-background/50 rounded">
            {capturedPieces.length > 0 ? (
            capturedPieces.map((p, i) => (
                <ChessPiece key={i} type={p.type} color={p.color} className="h-6 w-6" />
            ))
            ) : (
            <p className="text-xs text-muted-foreground px-2 self-center">No pieces captured</p>
            )}
        </div>
        <ScrollBar orientation="horizontal" />
      </ScrollArea>
    </div>
  );
}
