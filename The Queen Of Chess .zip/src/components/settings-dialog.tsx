"use client";

import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { Input } from "@/components/ui/input";
import { useSettings } from "@/hooks/use-settings";
import { Sun, Moon, Cog } from "lucide-react";

export function SettingsDialog() {
  const { theme, setTheme, lightSquareColor, setLightSquareColor, darkSquareColor, setDarkSquareColor } = useSettings();

  return (
    <Dialog>
      <DialogTrigger asChild>
        <Button variant="ghost" size="icon">
          <Cog className="h-6 w-6" />
          <span className="sr-only">Settings</span>
        </Button>
      </DialogTrigger>
      <DialogContent className="sm:max-w-[425px]">
        <DialogHeader>
          <DialogTitle>Settings</DialogTitle>
          <DialogDescription>
            Customize your The Queen Of Chess experience.
          </DialogDescription>
        </DialogHeader>
        <div className="grid gap-6 py-4">
          <div className="flex items-center justify-between">
            <Label htmlFor="theme-switcher" className="flex items-center gap-2 text-base">
              {theme === 'light' ? <Sun className="h-5 w-5" /> : <Moon className="h-5 w-5" />}
              Theme
            </Label>
            <Switch
              id="theme-switcher"
              checked={theme === 'dark'}
              onCheckedChange={(checked) => setTheme(checked ? 'dark' : 'light')}
            />
          </div>
          <div className="space-y-4">
            <h3 className="text-base font-medium">Board Colors</h3>
            <div className="flex items-center justify-between gap-4">
              <Label htmlFor="light-square-color" className="flex-1">Light Squares</Label>
              <Input
                id="light-square-color"
                type="color"
                value={lightSquareColor}
                onChange={(e) => setLightSquareColor(e.target.value)}
                className="w-16 h-10 p-1"
              />
            </div>
            <div className="flex items-center justify-between gap-4">
              <Label htmlFor="dark-square-color" className="flex-1">Dark Squares</Label>
              <Input
                id="dark-square-color"
                type="color"
                value={darkSquareColor}
                onChange={(e) => setDarkSquareColor(e.target.value)}
                className="w-16 h-10 p-1"
              />
            </div>
            <div className="p-4 rounded-md border" style={{
                background: `repeating-conic-gradient(${darkSquareColor} 0% 25%, ${lightSquareColor} 0% 50%) / 50% 50%`,
            }}>
                <div className="w-full h-16 rounded"></div>
            </div>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}
