"use client";

import { Button } from "@/components/ui/button";
import { Handshake, RotateCcw } from "lucide-react";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from "@/components/ui/alert-dialog";

interface GameControlsProps {
  onReset: () => void;
  onDraw: () => void;
}

export function GameControls({ onReset, onDraw }: GameControlsProps) {
  return (
    <div className="flex flex-col gap-2">
       <AlertDialog>
        <AlertDialogTrigger asChild>
         <Button variant="secondary" className="w-full">
            <Handshake className="mr-2 h-4 w-4" /> Offer Draw
          </Button>
        </AlertDialogTrigger>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Offer a draw?</AlertDialogTitle>
            <AlertDialogDescription>
             If the opponent accepts, the game will end in a draw.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction onClick={onDraw}>Offer Draw</AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
      
      <Button onClick={onReset} className="w-full">
        <RotateCcw className="mr-2 h-4 w-4" /> New Game
      </Button>
    </div>
  );
}
