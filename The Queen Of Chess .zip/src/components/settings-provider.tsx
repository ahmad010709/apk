"use client";

import React, { createContext, useState, useEffect, useCallback } from 'react';

export interface Settings {
  theme: 'light' | 'dark';
  lightSquareColor: string;
  darkSquareColor: string;
}

export interface SettingsContextType extends Settings {
  setTheme: (theme: 'light' | 'dark') => void;
  setLightSquareColor: (color: string) => void;
  setDarkSquareColor: (color: string) => void;
}

const defaultSettings: SettingsContextType = {
  theme: 'dark',
  lightSquareColor: '#f0d9b5',
  darkSquareColor: '#b58863',
  setTheme: () => {},
  setLightSquareColor: () => {},
  setDarkSquareColor: () => {},
};

export const SettingsContext = createContext<SettingsContextType>(defaultSettings);

export function SettingsProvider({ children }: { children: React.ReactNode }) {
  const [isMounted, setIsMounted] = useState(false);
  const [theme, setThemeState] = useState<'light' | 'dark'>('dark');
  const [lightSquareColor, setLightSquareColorState] = useState('#f0d9b5');
  const [darkSquareColor, setDarkSquareColorState] = useState('#b58863');

  useEffect(() => {
    try {
      const storedSettings = localStorage.getItem('the-queen-of-chess-settings');
      if (storedSettings) {
        const parsedSettings: Partial<Settings> = JSON.parse(storedSettings);
        if (parsedSettings.theme) setThemeState(parsedSettings.theme);
        if (parsedSettings.lightSquareColor) setLightSquareColorState(parsedSettings.lightSquareColor);
        if (parsedSettings.darkSquareColor) setDarkSquareColorState(parsedSettings.darkSquareColor);
      }
    } catch (error) {
      console.error("Failed to parse settings from localStorage", error);
    }
    setIsMounted(true);
  }, []);

  useEffect(() => {
    if (isMounted) {
      document.documentElement.classList.remove('light', 'dark');
      document.documentElement.classList.add(theme);

      try {
        const settingsToStore = JSON.stringify({ theme, lightSquareColor, darkSquareColor });
        localStorage.setItem('the-queen-of-chess-settings', settingsToStore);
      } catch (error) {
        console.error("Failed to save settings to localStorage", error);
      }
    }
  }, [theme, lightSquareColor, darkSquareColor, isMounted]);

  const setTheme = useCallback((newTheme: 'light' | 'dark') => {
    setThemeState(newTheme);
  }, []);

  const setLightSquareColor = useCallback((color: string) => {
    setLightSquareColorState(color);
  }, []);

  const setDarkSquareColor = useCallback((color: string) => {
    setDarkSquareColorState(color);
  }, []);

  if (!isMounted) {
    return null; // Or a loading spinner
  }

  const value = {
    theme,
    lightSquareColor,
    darkSquareColor,
    setTheme,
    setLightSquareColor,
    setDarkSquareColor,
  };

  return (
    <SettingsContext.Provider value={value}>
      {children}
    </SettingsContext.Provider>
  );
}
