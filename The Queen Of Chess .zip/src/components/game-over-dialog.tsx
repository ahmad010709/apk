"use client";

import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import Link from "next/link";
import { GameStatus } from "@/types";
import { Trophy, Handshake, Flag } from 'lucide-react';

interface GameOverDialogProps {
  status: GameStatus;
  winner?: 'w' | 'b';
  isOpen: boolean;
  onNewGame: () => void;
  onMenu?: () => void;
}

export function GameOverDialog({ status, winner, isOpen, onNewGame, onMenu }: GameOverDialogProps) {
  const getTitle = () => {
    switch(status) {
      case 'checkmate': return 'Checkmate!';
      case 'draw':
      case 'stalemate': return 'Draw!';
      case 'resigned': return 'Resigned!';
      default: return 'Game Over';
    }
  }

  const getDescription = () => {
     switch(status) {
      case 'checkmate': return `${winner === 'w' ? 'White' : 'Black'} wins by checkmate.`;
      case 'draw': return `The game is a draw by agreement.`;
      case 'stalemate': return `The game is a draw by stalemate.`;
      case 'resigned': return `${winner === 'w' ? 'White' : 'Black'} wins by resignation.`;
      default: return 'The game has ended.';
    }
  }

  const getIcon = () => {
    switch(status) {
        case 'checkmate':
        case 'resigned':
            return <Trophy className="h-16 w-16 text-primary mx-auto"/>;
        case 'draw':
        case 'stalemate':
            return <Handshake className="h-16 w-16 text-muted-foreground mx-auto"/>;
        default:
            return <Flag className="h-16 w-16 text-muted-foreground mx-auto"/>;
    }
  }


  return (
    <Dialog open={isOpen}>
      <DialogContent className="sm:max-w-md text-center">
        <DialogHeader>
            <div className="mb-4">{getIcon()}</div>
            <DialogTitle className="text-3xl font-bold">{getTitle()}</DialogTitle>
          <DialogDescription>
            {getDescription()}
          </DialogDescription>
        </DialogHeader>
        <DialogFooter className="sm:justify-center gap-2 pt-4">
          <Button onClick={onNewGame} className="w-full">New Game</Button>
          {onMenu ? (
             <Button variant="secondary" onClick={onMenu} className="w-full">
                Change Difficulty
            </Button>
          ) : (
            <Button variant="secondary" asChild className="w-full">
                <Link href="/">Main Menu</Link>
            </Button>
          )}
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
