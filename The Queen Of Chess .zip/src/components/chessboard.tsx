"use client";

import React, { useState } from 'react';
import type { Board, Move, Piece as PieceType } from '@/types';
import { useSettings } from '@/hooks/use-settings';
import { ChessPiece } from './chess-pieces';
import { cn } from '@/lib/utils';

interface ChessboardProps {
  board: Board;
  onMove: (move: Move) => void;
  getValidMoves: (row: number, col: number) => Move[];
  turn: 'w' | 'b';
  isFlipped?: boolean;
}

export function Chessboard({ board, onMove, getValidMoves, turn, isFlipped = false }: ChessboardProps) {
  const { lightSquareColor, darkSquareColor } = useSettings();
  const [selectedPiece, setSelectedPiece] = useState<{ row: number; col: number } | null>(null);
  const [validMoves, setValidMoves] = useState<Move[]>([]);

  const handleSquareClick = (row: number, col: number) => {
    if (selectedPiece) {
      const move = { from: selectedPiece, to: { row, col } };
      const isMoveValid = validMoves.some(m => m.to.row === row && m.to.col === col);
      if (isMoveValid) {
        onMove(move);
        setSelectedPiece(null);
        setValidMoves([]);
      } else if (board[row][col]?.color === turn) {
        selectPiece(row, col);
      } else {
        setSelectedPiece(null);
        setValidMoves([]);
      }
    } else {
      selectPiece(row, col);
    }
  };

  const selectPiece = (row: number, col: number) => {
    const piece = board[row][col];
    if (piece && piece.color === turn) {
      setSelectedPiece({ row, col });
      setValidMoves(getValidMoves(row, col));
    } else {
      setSelectedPiece(null);
      setValidMoves([]);
    }
  };

  const renderBoard = () => {
    const boardToRender = isFlipped ? [...board].reverse().map(row => [...row].reverse()) : board;
    
    return boardToRender.map((row, rIdx) => (
      <React.Fragment key={rIdx}>
        {row.map((piece, cIdx) => {
          const originalRow = isFlipped ? 7 - rIdx : rIdx;
          const originalCol = isFlipped ? 7 - cIdx : cIdx;

          const isLight = (originalRow + originalCol) % 2 !== 0;
          const isSelected = selectedPiece?.row === originalRow && selectedPiece?.col === originalCol;
          const isValidMove = validMoves.some(m => m.to.row === originalRow && m.to.col === originalCol);

          return (
            <div
              key={`${originalRow}-${originalCol}`}
              onClick={() => handleSquareClick(originalRow, originalCol)}
              className="relative aspect-square cursor-pointer"
              style={{ backgroundColor: isLight ? lightSquareColor : darkSquareColor }}
            >
              {piece && <ChessPiece type={piece.type} color={piece.color} className="w-full h-full p-1 drop-shadow-lg" />}
              {isSelected && <div className="absolute inset-0 bg-primary/50" />}
              {isValidMove && (
                <div className="absolute inset-0 flex items-center justify-center">
                  <div className={cn(
                    "rounded-full bg-primary/40",
                    board[originalRow][originalCol] ? "w-full h-full border-4 border-primary/60" : "w-1/3 h-1/3"
                  )}></div>
                </div>
              )}
            </div>
          );
        })}
      </React.Fragment>
    ));
  };
  
  return (
    <div className="grid grid-cols-8 w-full max-w-[min(calc(100vh-12rem),90vw)] mx-auto aspect-square shadow-2xl rounded-lg overflow-hidden border-4 border-card">
      {renderBoard()}
    </div>
  );
}
