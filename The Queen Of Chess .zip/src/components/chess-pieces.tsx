import type { PieceType, PieceColor } from '@/types';

interface ChessPieceProps extends React.SVGProps<SVGSVGElement> {
  type: PieceType;
  color: PieceColor;
}

// For white pieces, we want a transparent fill so only the stroke is visible.
// For black pieces, we want them filled with the foreground color.
const pieceFill: Record<PieceColor, string> = {
  b: 'hsl(var(--foreground))',
  w: 'transparent',
};

// Both pieces will have a stroke based on the foreground color.
const pieceStroke: Record<PieceColor, string> = {
  b: 'hsl(var(--foreground))',
  w: 'hsl(var(--foreground))',
};


const pieces: Record<PieceColor, Record<PieceType, React.FC<React.SVGProps<SVGSVGElement>>>> = {
  // The paths are the same for both colors, the fill/stroke styling will differentiate them.
  b: {
    pawn: (props) => <path {...props} d="M22.5 38c-3.31 0-6-2.69-6-6s2.69-6 6-6 6 2.69 6 6-2.69 6-6 6zm-1-16.5c-3-2.5-6-4.5-6-4.5s-3 2-6 4.5c-3 2.5-3 5.5-3 5.5s1 2 3 2h12c2 0 3-2 3-2s0-3-3-5.5z" />,
    rook: (props) => <path {...props} d="M31 38H14c-1.1 0-2-.9-2-2V18h2v18h15V18h2v18c0 1.1-.9 2-2 2zM14 14h17v-4H14v4zm3-6h11V6H17v2z" />,
    knight: (props) => <path {...props} d="M22.5 38c-1.66 0-3-1.34-3-3s1.34-3 3-3 3 1.34 3 3-1.34 3-3 3zM21 8.5c1.83-2.33 3.5-5 3.5-7.5 0-2.21-1.79-4-4-4s-4 1.79-4 4c0 2.5 1.67 5.17 3.5 7.5.49.62 1.51.62 2 0zM12 10.5c-1.5-2.5-2.5-5-2.5-7.5 0-2.21-1.79-4-4-4s-4 1.79-4 4c0 2.5 1 5 2.5 7.5.49.62 1.51.62 2 0z" />,
    bishop: (props) => <path {...props} d="M22.5 38c-1.66 0-3-1.34-3-3s1.34-3 3-3 3 1.34 3 3-1.34 3-3 3zm-2-12.5c-1.5-2.5-2.5-5-2.5-7.5 0-2.76 1.12-5.26 2.93-7.07.52-.52 1.38-.52 1.9 0l.17.17c.52.52.52 1.38 0 1.9C23.12 10.74 22 13.24 22 16c0 2.5.78 4.7 2.07 6.43.52.52.52 1.38 0 1.9l-.17.17c-.52.52-1.38.52-1.9 0z" />,
    queen: (props) => <path {...props} d="M8 12a2 2 0 1 1-4 0 2 2 0 0 1 4 0zm16.5-4.5a2 2 0 1 1-4 0 2 2 0 0 1 4 0zm15.5 4.5a2 2 0 1 1-4 0 2 2 0 0 1 4 0zM12 25.5a2 2 0 1 1-4 0 2 2 0 0 1 4 0zm24 0a2 2 0 1 1-4 0 2 2 0 0 1 4 0zM8 12S15 23 22.5 23 37 12 37 12V6l-7.5 2-7.5-3-7.5 3L8 6v6z" />,
    king: (props) => <path {...props} d="M22.5 11.63V6M20 8h5m2.5 17s4.5-7.5 3-10.5c0 0-1.5-3-3-3s-3 3-3 3c-1.5 3 3 10.5 3 10.5" />,
  },
  w: {
    pawn: (props) => <path {...props} d="M22.5 38c-3.31 0-6-2.69-6-6s2.69-6 6-6 6 2.69 6 6-2.69 6-6 6zm-1-16.5c-3-2.5-6-4.5-6-4.5s-3 2-6 4.5c-3 2.5-3 5.5-3 5.5s1 2 3 2h12c2 0 3-2 3-2s0-3-3-5.5z" />,
    rook: (props) => <path {...props} d="M31 38H14c-1.1 0-2-.9-2-2V18h2v18h15V18h2v18c0 1.1-.9 2-2 2zM14 14h17v-4H14v4zm3-6h11V6H17v2z" />,
    knight: (props) => <path {...props} d="M22.5 38c-1.66 0-3-1.34-3-3s1.34-3 3-3 3 1.34 3 3-1.34 3-3 3zM21 8.5c1.83-2.33 3.5-5 3.5-7.5 0-2.21-1.79-4-4-4s-4 1.79-4 4c0 2.5 1.67 5.17 3.5 7.5.49.62 1.51.62 2 0zM12 10.5c-1.5-2.5-2.5-5-2.5-7.5 0-2.21-1.79-4-4-4s-4 1.79-4 4c0 2.5 1 5 2.5 7.5.49.62 1.51.62 2 0z" />,
    bishop: (props) => <path {...props} d="M22.5 38c-1.66 0-3-1.34-3-3s1.34-3 3-3 3 1.34 3 3-1.34 3-3 3zm-2-12.5c-1.5-2.5-2.5-5-2.5-7.5 0-2.76 1.12-5.26 2.93-7.07.52-.52 1.38-.52 1.9 0l.17.17c.52.52.52 1.38 0 1.9C23.12 10.74 22 13.24 22 16c0 2.5.78 4.7 2.07 6.43.52.52.52 1.38 0 1.9l-.17.17c-.52.52-1.38.52-1.9 0z" />,
    queen: (props) => <path {...props} d="M8 12a2 2 0 1 1-4 0 2 2 0 0 1 4 0zm16.5-4.5a2 2 0 1 1-4 0 2 2 0 0 1 4 0zm15.5 4.5a2 2 0 1 1-4 0 2 2 0 0 1 4 0zM12 25.5a2 2 0 1 1-4 0 2 2 0 0 1 4 0zm24 0a2 2 0 1 1-4 0 2 2 0 0 1 4 0zM8 12S15 23 22.5 23 37 12 37 12V6l-7.5 2-7.5-3-7.5 3L8 6v6z" />,
    king: (props) => <path {...props} d="M22.5 11.63V6M20 8h5m2.5 17s4.5-7.5 3-10.5c0 0-1.5-3-3-3s-3 3-3 3c-1.5 3 3 10.5 3 10.5" />,
  },
};

export const ChessPiece: React.FC<ChessPieceProps> = ({ type, color, className, ...props }) => {
    const PieceComponent = pieces[color]?.[type];

    if (!PieceComponent) {
      return null;
    }

    return (
        <svg
            viewBox="0 0 45 45"
            className={className}
            fill={pieceFill[color]}
            stroke={pieceStroke[color]}
            strokeWidth="1.5"
            strokeLinejoin="round"
            {...props}
        >
            <PieceComponent />
        </svg>
    );
};
