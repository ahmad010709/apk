import type { Board, Move, Piece, PieceColor, Square } from '@/types';

export const INITIAL_BOARD: Board = [
  [{type: 'rook', color: 'b'}, {type: 'knight', color: 'b'}, {type: 'bishop', color: 'b'}, {type: 'queen', color: 'b'}, {type: 'king', color: 'b'}, {type: 'bishop', color: 'b'}, {type: 'knight', color: 'b'}, {type: 'rook', color: 'b'}],
  Array(8).fill({type: 'pawn', color: 'b'}),
  Array(8).fill(null),
  Array(8).fill(null),
  Array(8).fill(null),
  Array(8).fill(null),
  Array(8).fill({type: 'pawn', color: 'w'}),
  [{type: 'rook', color: 'w'}, {type: 'knight', color: 'w'}, {type: 'bishop', color: 'w'}, {type: 'queen', color: 'w'}, {type: 'king', color: 'w'}, {type: 'bishop', color: 'w'}, {type: 'knight', color: 'w'}, {type: 'rook', color: 'w'}],
];

export function createInitialBoard(): Board {
  // Use structuredClone for a deep copy to prevent mutation issues.
  return structuredClone(INITIAL_BOARD);
}

function isWithinBounds(row: number, col: number): boolean {
  return row >= 0 && row < 8 && col >= 0 && col < 8;
}

export function getValidMoves(row: number, col: number, board: Board): Move[] {
  const piece = board[row]?.[col];
  if (!piece) return [];

  const moves: Move[] = [];
  const from = { row, col };
  const { type, color } = piece;

  const addMove = (toRow: number, toCol: number) => {
    if (isWithinBounds(toRow, toCol)) {
      const targetPiece = board[toRow][toCol];
      if (targetPiece === null || targetPiece.color !== color) {
        moves.push({ from, to: { row: toRow, col: toCol } });
      }
    }
  };

  const addSlidingMoves = (directions: number[][]) => {
    for (const [dr, dc] of directions) {
      let r = row + dr;
      let c = col + dc;
      while (isWithinBounds(r, c)) {
        const targetPiece = board[r][c];
        if (targetPiece === null) {
          moves.push({ from, to: { row: r, col: c } });
        } else {
          if (targetPiece.color !== color) {
            moves.push({ from, to: { row: r, col: c } });
          }
          break;
        }
        r += dr;
        c += dc;
      }
    }
  };

  switch (type) {
    case 'pawn':
      const dir = color === 'w' ? -1 : 1;
      const startRow = color === 'w' ? 6 : 1;

      // Forward 1
      if (isWithinBounds(row + dir, col) && board[row + dir][col] === null) {
        addMove(row + dir, col);
        // Forward 2 from start
        if (row === startRow && board[row + 2 * dir][col] === null) {
          addMove(row + 2 * dir, col);
        }
      }
      // Captures
      [-1, 1].forEach(side => {
        if (isWithinBounds(row + dir, col + side)) {
          const target = board[row + dir][col + side];
          if (target && target.color !== color) {
            addMove(row + dir, col + side);
          }
        }
      });
      break;

    case 'knight':
      const knightMoves = [[-2, -1], [-2, 1], [-1, -2], [-1, 2], [1, -2], [1, 2], [2, -1], [2, 1]];
      knightMoves.forEach(([dr, dc]) => addMove(row + dr, col + dc));
      break;

    case 'bishop':
      addSlidingMoves([[-1, -1], [-1, 1], [1, -1], [1, 1]]);
      break;

    case 'rook':
      addSlidingMoves([[-1, 0], [1, 0], [0, -1], [0, 1]]);
      break;

    case 'queen':
      addSlidingMoves([[-1, -1], [-1, 1], [1, -1], [1, 1], [-1, 0], [1, 0], [0, -1], [0, 1]]);
      break;

    case 'king':
      const kingMoves = [[-1, -1], [-1, 0], [-1, 1], [0, -1], [0, 1], [1, -1], [1, 0], [1, 1]];
      kingMoves.forEach(([dr, dc]) => addMove(row + dr, col + dc));
      break;
  }

  return moves;
}

export function getAllPossibleMoves(board: Board, color: PieceColor): Move[] {
  const allMoves: Move[] = [];
  for (let r = 0; r < 8; r++) {
    for (let c = 0; c < 8; c++) {
      const piece = board[r][c];
      if (piece && piece.color === color) {
        allMoves.push(...getValidMoves(r, c, board));
      }
    }
  }
  return allMoves;
}
